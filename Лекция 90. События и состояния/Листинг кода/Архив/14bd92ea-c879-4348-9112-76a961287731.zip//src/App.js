import { LikeButton } from "./components/LikeButton";
// import { LikeButtonFC } from './components/LikeButtonFC'
// import { LikeButtonCC } from './components/LikeButtonCC'

import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <LikeButton />
      {/* <LikeButtonFC /> */}
      {/* <LikeButtonCC /> */}
    </div>
  );
}
