import "./footer.scss";
export const Footer = () => {
  return <footer className="footer">&copy;2023 React router</footer>;
};
