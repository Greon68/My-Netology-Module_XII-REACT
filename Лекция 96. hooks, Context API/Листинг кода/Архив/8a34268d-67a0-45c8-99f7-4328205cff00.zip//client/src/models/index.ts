export interface INews {
  id: string;
  content: string;
}
