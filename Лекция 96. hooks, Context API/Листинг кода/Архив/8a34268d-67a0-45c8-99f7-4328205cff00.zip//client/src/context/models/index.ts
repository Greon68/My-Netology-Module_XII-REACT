export type News = {
  id: string;
  content: string;
};
