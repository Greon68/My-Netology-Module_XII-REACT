export type PurchaseModel = {
	id: number
	name: string
	done?: boolean
}
