export type UserModel = {
	name: string
	position: string
	avatar: string
}
